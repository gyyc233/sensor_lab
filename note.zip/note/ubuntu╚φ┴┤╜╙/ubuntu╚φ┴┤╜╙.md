
1. 创建软连接，将`/path/to/original`链接到`/path/to/link`，`/path/to/link`是一个新的文件或目录

```shell
ln -s /path/to/original /path/to/link
```

2. 删除软连接`/path/to/link`

```shell
rm -rf /path/to/link
```

注意：如果链接的是文件夹，在删除的时候不要加斜杠/，也就是rm -rf /path/to/link/，这样会将源目录下的文件一起删除(阿弥诺斯)

3. 修改软连接, 将`/path/to/link`链接到`/path/to/original_2`

```shell
ln -snf /path/to/original_2 /path/to/link
```

4. 查看软连接 `ls -l`

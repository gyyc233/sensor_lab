- [SSH](#ssh)
- [SCP](#scp)


## SSH

- install ssh

```bash
sudo apt-get install openssh-client 
sudo apt-get install openssh-server
```

- launch and restart ssh

```bash
sudo /etc/init.d/ssh start

sudo /etc/init.d/ssh stop  #server stop ssh
sudo /etc/init.d/ssh restart  #server restart ssh
```

- shh remote host, default port 22

```bash
ssh user_name@10.215.22.33
```

- set port `ssh -p 2233 user_name@10.215.22.33`

## SCP

assume A: local host user name; B: remote host user name

- copy files from the remote machine to the local machine

```bash
scp B@192.168.0.100:/home/B/filename .
```

- copy files from the local machine to the remote machine

```bash
scp filename B@192.168.0.100:/home/B/ws
```


- create tag `git tag label_name` or `git tag label_name commit_id`
- delete tag `git tag -d commit_id`
- push tag to remote `git push origin label_name` or `git push origin --tags`
- delete remote tag `git push origin --delete label_name` or `git push origin :regs/tags/label_name`
- check tag `git checkout label_name`
- based on tag checkout new branch `git checkout -b hotfix label_name`

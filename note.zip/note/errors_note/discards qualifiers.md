
- 错误信息

```bash
error: passing ‘const xxx’ as ‘this’ argument discards qualifiers [-fpermissive]
```

直译：错误:将“const xxx”作为“this”参数传递会丢弃限定词。
discards qualifiers：丢弃限定符，当尝试修改const类型时，会报discards qualifiers
-fpermissive：将有关不合格代码的某些诊断从错误降级为警告。因此，使用-fpermissive将允许编译一些不合格的代码。

- 错误复现

```cpp
struct Count{
    uint32_t c;

    Count(uint32_t i=0):c(i){}

    uint32_t getCount(){
        return c;
    }

    uint32_t add(const Count& count){
        uint32_t total = c + count.getCount();
        return total;
    }
};
```

add(const Count& count)的参数count是const的，在函数内部使用是调用了count.getCount()；但是getCount是非const的。
修改方法：
将uint32_t getCount(){…}为 uint32_t getCount() const {…}

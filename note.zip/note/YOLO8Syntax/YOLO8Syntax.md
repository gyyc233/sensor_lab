- [YOLO8 Syntax](#yolo8-syntax)
  - [YOLO8 CLI](#yolo8-cli)
  - [Train](#train)
  - [Val 验证](#val-验证)
  - [Predict](#predict)
  - [Export](#export)
- [Python](#python)
  - [Train](#train-1)
  - [Val](#val)
  - [Predict](#predict-1)
  - [Export](#export-1)
  - [Track](#track)
- [常见名词含义](#常见名词含义)

# YOLO8 Syntax

## YOLO8 CLI

- YOLO command line interfaces CLI syntax

scan all arg `yolo cfg`

```
yolo TASK MODE ARGS

Where   TASK (optional) is one of [detect 检测 , segment 配准 , classify 分类 ]
        MODE (required) is one of [train, val(验证), predict(预测), export(导出), track]
        ARGS (optional) are any number of custom 'arg=value' pairs like 'imgsz=320' that override defaults.
```

## Train

Train YOLOv8n on the COCO128 dataset for 100 epochs at image size 640. 
在COCO128上以图像大小 640 训练 YOLOv8n 100 个 epoch

```
yolo detect train data=coco128.yaml model=yolov8n.pt epochs=100 imgsz=640
```

恢复中断的训练 resume

```
yolo detect train resume model=last.pt
```

## Val 验证

Validate trained YOLOv8n model accuracy on the COCO128 dataset. No argument need to passed as the model retains it's training data and arguments as model attributes. 在COCO128数据集上验证经过训练的 YOLOv8n 模型准确性。无需传递任何参数，因为模型将其训练数据和参数保留为模型属性。

```
yolo detect val model=yolov8n.pt
```

resume
```
yolo detect val model=path/to/best.pt
```

## Predict

Use a trained YOLOv8n model to run predictions on images.使用经过训练的 YOLOv8n 模型对图像运行预测。

```
yolo detect predict model=yolov8n.pt source='https://ultralytics.com/images/bus.jpg'
```

resume
```
yolo detect predict model=path/to/best.pt source='https://ultralytics.com/images/bus.jpg'
```

## Export

Export a YOLOv8n model to a different format like ONNX, CoreML, etc.将 YOLOv8n 模型导出为不同的格式，如 ONNX、CoreML 等

```
yolo export model=yolov8n.pt format=onnx
```

resume

```
yolo export model=path/to/best.pt format=onnx
```

# Python

- how to load and use pretrained models
- train new models
- perform predictions on images

For example, users can load a model, train it, evaluate its performance on a validation set, and even export it to ONNX format with just a few lines of code. 加载，训练，评估在验证集上的性能，导出ONNX格式

```python
from ultralytics import YOLO

# Create a new YOLO model from scratch (from scratch 白手起家)
model = YOLO('yolov8n.yaml')

# Load a pretrained YOLO model (recommended for training) 加载预训练模型
model = YOLO('yolov8n.pt')

# Train the model using the 'coco128.yaml' dataset for 3 epochs 使用'coco128.yaml'数据集对模型进行训练，训练3个epoch
results = model.train(data='coco128.yaml', epochs=3)

# Evaluate the model's performance on the validation set 在验证集上评估模型的性能
results = model.val()

# Perform object detection on an image using the model 使用模型对图像进行目标检测
results = model('https://ultralytics.com/images/bus.jpg')

# Export the model to ONNX format 将模型导出为ONNX格式
success = model.export(format='onnx')
```

## Train

- pretrained 使用预训练模型

```python
from ultralytics import YOLO

model = YOLO('yolov8n.pt') # pass any model type
results = model.train(epochs=5)
```

- from scratch 初始训练

```python
from ultralytics import YOLO

model = YOLO('yolov8n.yaml')
results = model.train(data='coco128.yaml', epochs=5)
```

- resume

```python
model = YOLO("last.pt")
results = model.train(resume=True)
```

## Val

Val mode is used for validating a YOLOv8 model after it has been trained. In this mode, the model is evaluated on a validation set to measure its accuracy and generalization performance. This mode can be used to tune the hyperparameters of the model to improve its performance.
Val 模式**用于在训练 YOLOv8 模型后对其进行验证**。在此模式下，模型在验证集上进行评估，以测量其准确性和泛化性能。此模式可用于调整模型的超参数以提高其性能。

- Val after train 训练后验证

```python
from ultralytics import YOLO

# 导入YOLO模型
model = YOLO('yolov8n.yaml')
# 使用'coco128.yaml'数据集对模型进行训练，训练5个epoch
model.train(data='coco128.yaml', epochs=5)
model.val()  # It'll automatically evaluate the data you trained.
```

- Val independently 单独验证

```python
from ultralytics import YOLO

model = YOLO("model.pt")
# It'll use the data YAML file in model.pt if you don't set data.
model.val()
# or you can set the data you want to val
model.val(data='coco128.yaml')
```

## Predict

Predict mode is used for making predictions using a trained YOLOv8 model on new images or videos.In this mode, the model is loaded from a checkpoint file, and the user can provide images or videos to perform inference. The model predicts the classes and locations of objects in the input images or videos.

```python
from ultralytics import YOLO
from PIL import Image
import cv2

model = YOLO("model.pt")
# accepts all formats - image/dir/Path/URL/video/PIL/ndarray. 0 for webcam
results = model.predict(source="0")
results = model.predict(source="folder", show=True) # Display preds. Accepts all YOLO predict arguments

# from PIL 使用PIL库
im1 = Image.open("bus.jpg")
results = model.predict(source=im1, save=True)  # save plotted images 保存绘制的图像

# from ndarray
im2 = cv2.imread("bus.jpg")
# 将预测结果保存为标签
results = model.predict(source=im2, save=True, save_txt=True)  # save predictions as labels

# from list of PIL/ndarray
# 使用PIL/ndarray列表
results = model.predict(source=[im1, im2])
```

- result usage

```
# results would be a list of Results object including all the predictions by default
# but be careful as it could occupy a lot memory when there're many images,
# especially the task is segmentation.
# 1. return as a list
results = model.predict(source="folder")

# results would be a generator which is more friendly to memory by setting stream=True
# 2. return as a generator
results = model.predict(source=0, stream=True)

for result in results:
    # Detection
    result.boxes.xyxy   # box with xyxy format, (N, 4)
    result.boxes.xywh   # box with xywh format, (N, 4)
    result.boxes.xyxyn  # box with xyxy format but normalized, (N, 4)
    result.boxes.xywhn  # box with xywh format but normalized, (N, 4)
    result.boxes.conf   # confidence score, (N, 1)
    result.boxes.cls    # cls, (N, 1)

    # Segmentation
    result.masks.data      # masks, (N, H, W)
    result.masks.xy        # x,y segments (pixels), List[segment] * N
    result.masks.xyn       # x,y segments (normalized), List[segment] * N

    # Classification
    result.probs     # cls prob, (num_class, )

# Each result is composed of torch.Tensor by default,
# in which you can easily use following functionality:
# result 内部是Tensor格式
result = result.cuda()
result = result.cpu()
result = result.to("cpu")
result = result.numpy()
```

## Export

Export mode is used for exporting a YOLOv8 model to a format that can be used for deployment. In this mode, the model is converted to a format that can be used by other software applications or hardware devices. This mode is useful when deploying the model to production environments.
导出模式用于将 YOLOv8 模型导出为可用于部署的格式。在此模式下，模型将转换为可供其他软件应用程序或硬件设备使用的格式。将模型部署到生产环境时，此模式非常有用。

- export to ONNX
- Export an official YOLOv8n model to ONNX with dynamic batch-size and image-size.

```python
from ultralytics import YOLO

model = YOLO('yolov8n.pt')
model.export(format='onnx', dynamic=True)
```

- export to TensorRT
- Export an official YOLOv8n model to TensorRT on device=0 for acceleration on CUDA devices.

```python
from ultralytics import YOLO

model = YOLO('yolov8n.pt')
model.export(format='onnx', device=0)
```

## Track




# 常见名词含义

- coco128:COCO128是一个小型教程数据集，由COCOtrain2017中的前128个图像组成
- epochs(时期):当一个完整的数据集通过了神经网络一次并且返回了一次，这个过程称为一次>epoch。（也就是说，所有训练样本在神经网络中都 进行了一次正向传播 和一次反向传播 ）
  - 一个Epoch就是将所有训练样本训练一次的过程
  - 然而，当一个Epoch的样本（也就是所有的训练样本）数量可能太过庞大（对于计算机而言），就需要把它分成多个小块，也就是就是分成多个Batch 来进行训练。
- Batch(批/一批样本):将整个训练样本分成若干个Batch
- Batch_Size 批大小:每批样本的大小，一次训练所选取的样本数。
  - Batch Size的大小影响模型的优化程度和速度。同时其直接影响到GPU内存的使用情况，假如GPU内存不大，该数值最好设置小一点
  - Batch Size合适的优点
    - 让GPU满载运行，提高训练速
    - 单个epoch的迭代次数减少了，参数的调整也慢了，假如要达到相同的识别精度，需要更多的epoch
    - 适当Batch Size使得梯度下降方向更加准确
  - Batch Size从小到大的变化对网络影响
    - 没有Batch Size，梯度准确，只适用于小样本数据库
    - Batch Size=1，梯度变来变去，非常不准确，网络很难收敛
    - Batch Size增大，梯度变准确
    - Batch Size增大，梯度已经非常准确，再增加Batch Size也没有用
    - 注意：Batch Size增大了，要到达相同的准确度，必须要增大epoch
- Iteration 一次迭代:训练一个Batch就是一次Iteration（这个概念跟程序语言中的迭代器相似）
- 为什么要使用多于一个epoch
  - epoch数量增加，神经网络中的权重的更新次数也在增加，曲线从欠拟合变得过拟合。到底多少个epoch最合适，这个问题没有正确答案，对于不同的数据集，答案都不相同
- GD（Gradient Descent）：就是没有利用Batch Size，用基于整个数据库得到梯度，梯度准确，但数据量大时，计算非常耗时，同时神经网络常是非凸的，网络最终可能收敛到初始点附近的局部最优点。
- SGD（Stochastic Gradient Descent）：就是Batch Size=1，每次计算一个样本，梯度不准确，所以学习率要降低。
- mini-batch SGD：就是选着合适Batch Size的SGD算法，mini-batch利用噪声梯度，一定程度上缓解了GD算法直接掉进初始点附近的局部最优值。同时梯度准确了，学习率要加大。
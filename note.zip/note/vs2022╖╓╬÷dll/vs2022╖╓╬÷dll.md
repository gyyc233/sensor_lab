- [vs2022分析dll](#vs2022分析dll)
  - [查看x64dll](#查看x64dll)
    - [PE文件头](#pe文件头)
    - [输出信息到文本文件](#输出信息到文本文件)

# vs2022分析dll

open Visual Studio 2022 `Developer Command Prompt for vs2022`

tool: dumpbin

```bash
C:\Program Files\Microsoft Visual Studio\2022\Community>dumpbin
Microsoft (R) COFF/PE Dumper Version 14.38.33133.0
Copyright (C) Microsoft Corporation.  All rights reserved.

用法: DUMPBIN [选项] [文件]

  选项:

   /ALL
   /ARCHIVEMEMBERS
   /CLRHEADER
   /DEPENDENTS
   /DIRECTIVES
      /DISASM[:{BYTES|NOBYTES|NOWIDE|WIDE}]
   /ERRORREPORT:{NONE|PROMPT|QUEUE|SEND}
   /EXPORTS
   /FPO
   /HEADERS
   /IMPORTS[:文件名]
      /LINENUMBERS
      /LINKERMEMBER[:{1|2|4|8|16|32}]
   /LOADCONFIG
   /NOLOGO
      /NOPDB
      /NOSECTION:name
      /OUT:文件名
      /OTHERARCHEXPORTS (需要 /EXPORTS)
      /PDATA
   /PDBPATH[:VERBOSE]
   /RANGE:vaMin[,vaMax]
   /RAWDATA[:{NONE|1|2|4|8}[,#]]
   /RELOCATIONS
   /SECTION:名称
(按回车键继续)
   /SUMMARY
   /SYMBOLS
   /TLS
   /UNWINDINFO
```

## 查看x64dll


### PE文件头

[PE文件之标准PE头](https://blog.csdn.net/m0_46125480/article/details/120954398)

`dumpbin /HEADERS D:\yongchao_gan\work_space\code\DLL_API\x64\Release\CalibrationParams.dll`

```bash
File Type: DLL

FILE HEADER VALUES
            8664 machine (x64)
               6 number of sections
        65E54A37 time date stamp Mon Mar  4 12:12:39 2024
               0 file pointer to symbol table
               0 number of symbols
              F0 size of optional header
            2022 characteristics
                   Executable
                   Application can handle large (>2GB) addresses
                   DLL
```

```c
typedef     struct _IMAGE_FILE_HEADER 
{
+04h    WORD        Machine;              // 运行平台
+06h    WORD        NumberOfSections;     // 文件的区块数目
+08h    DWORD       TimeDateStamp;        // 文件创建日期和时间
+0Ch    DWORD       PointerToSymbolTable; // 指向符号表(主要用于调试)
+10h    DWORD       NumberOfSymbols;      // 符号表中符号个数(同上)
+14h    WORD        SizeOfOptionalHeader; // IMAGE_OPTIONAL_HEADER32 结构大小
+16h    WORD        Characteristics;      // 文件属性
} IMAGE_FILE_HEADER, *PIMAGE_FILE_HEADER;
```

### 输出信息到文本文件

```bash
C:\Program Files\Microsoft Visual Studio\2022\Community>dumpbin /IMPORTS D:\uids0025\Desktop\aaa\3\CalibrationParams.dll > D:\uids0025\Desktop\aaa\3\2.txt
```

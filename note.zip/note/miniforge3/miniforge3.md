# miniforge3

miniforge3一般用于平替Anaconda和miniconda，是一个轻量级的conda发行版，它是一个conda包管理系统的替代品，可以安装Python包和其依赖项

## install

```bash
wget https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh

# 如果失败，可以尝试 bash Miniforge3-Linux-x86_64.sh -b
# -b 表示安装时不需要询问,参考 https://github.com/conda-forge/miniforge/issues/716
bash Miniforge3-Linux-x86_64.sh

# select install path

# add to PATH

```

## config environment path

```bash
vi ~/.bashrc
# add new line
export PATH="/path/to/miniforge3/bin:$PATH"

source ~/.bashrc
```

## check minifprge3

```bash
conda --version
```

## usage

```bash
# create a new environment
conda create -n myenv python=3.8

# activate the environment
conda activate myenv
```

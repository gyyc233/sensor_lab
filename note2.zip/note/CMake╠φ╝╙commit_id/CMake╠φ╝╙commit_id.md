- [CMake添加commit\_id](#cmake添加commit_id)

# CMake添加commit_id

- add commit SHA1 to CMakeLists.txt

```
# add commit SHA1
execute_process(
    COMMAND bash "-c" "git log|head -n 1|awk '{printf $2}'"
    OUTPUT_VARIABLE GIT_COMMIT
)

add_definitions(-DGIT_COMMIT_SHA1="${GIT_COMMIT}")
# add commit SHA1
```

- printf commit SHA1

```cpp
std::cout << "build_sha1: " << GIT_COMMIT_SHA1
          << "\nbuild_time:: " << __DATE__ << " " << __TIME__ << std::endl;
```

```
build_sha1: 64fe196ba3b3127cd0c24fdc150051267d31151c
build_time:: Feb 29 2024 16:53:25
```

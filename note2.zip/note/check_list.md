## 相关名词

DMS Driver Monitoring System，监测对象为Driver(驾驶员)

OMS，即Occupancy Monitoring System，监测对象为乘客

In-cabin monitoring System即汽车座舱的智能视觉监控系统。通俗来讲，IMS既包括DMS、OMS，也包括FACE ID、手势识别、体征监测、远程监控等

ADAS是Advanced Driver Assistance System的简称，翻译成中文的意思就是高级驾驶辅助系统。就是利用安装在车上的各式各样传感器收集数据，并结合地图数据进行系统计算，从而预先为驾驶者判断可能发生的危险，保证行车的安全性



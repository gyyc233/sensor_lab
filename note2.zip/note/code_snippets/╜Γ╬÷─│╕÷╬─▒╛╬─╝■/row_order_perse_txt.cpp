    std::ifstream infile;
    infile.open("D:\\yongchao_gan\\work_space\\T68\\20240408\\diy\\1\\2211.txt", std::ios::in);
    if (!infile.is_open())
    {
        std::cout << "failed to read file" << std::endl;
        return -3;
    }
    char buf[1024];
    while (infile.getline(buf, sizeof(buf)))
    {
        std::string aaa = buf;
        aaa = aaa.substr(0, aaa.size() - 36);
        aaa = aaa.substr(21, aaa.size()-20);
        aaa.erase(remove(aaa.begin(), aaa.end(), 'y'), aaa.end());
        aaa.erase(remove(aaa.begin(), aaa.end(), ' '), aaa.end());
        aaa.erase(remove(aaa.begin(), aaa.end(), ':'), aaa.end());
        std::replace(aaa.begin(), aaa.end(), ',', '=');
        std::cout << aaa << std::endl;
    }
    infile.close();
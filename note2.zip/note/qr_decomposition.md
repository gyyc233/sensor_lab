- [QR分解](#qr分解)
  - [QR分解步骤](#qr分解步骤)
    - [Example](#example)

# QR分解

- 矩阵A可以分解为正交矩阵Q~n*n~乘以非奇异上三角矩阵R~n*n~,A=QR
- 对于m*n的列满秩矩阵A，有A~m*n~=Q~m*n~ * R~n*n~ 其中Q为正交向量组，R为非奇异上三角矩阵，该分解也叫做QR分解
- QR分解用于求解A的特征值、A的逆，最小二乘等问题

## QR分解步骤

1. 列出矩阵A的列向量(a1,a2,a3)
2. 施密特正交化得到(b1,b2,b3)
3. 单位化(b1,b2,b3)，得到矩阵Q
4. 把矩阵A列向量表达为(b1,b2,b3)的线性组合，则系数矩阵为R矩阵（上三角矩阵）

### Example

![](qr_decomposition/qr_2.png)

![](qr_decomposition/qr_1.png)

![](qr_decomposition/qr_3.png)
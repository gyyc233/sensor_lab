- [ubuntu查看程序运行情况](#ubuntu查看程序运行情况)
  - [查找进程id](#查找进程id)
  - [查看内存](#查看内存)
    - [top 指令查看](#top-指令查看)
    - [ps指令查看](#ps指令查看)
  - [查看内存占用前10名的程序](#查看内存占用前10名的程序)

# ubuntu查看程序运行情况

assume run ./test process

## 查找进程id

using ps cmd find process id

```bash
ps -ef |grep test 
kernoops    1005       1  0 1月16 ?       00:01:30 /usr/sbin/kerneloops --test
uids0025  940326  938795  0 10:38 pts/1    00:00:00 ./test
uids0025  940471  939814  0 10:40 pts/0    00:00:00 grep --color=auto test
```

find process id: 940326

## 查看内存

### top 指令查看

- using top cmd check memory

```bash
top -p 940326

Tasks:   1 total,   0 running,   1 sleeping,   0 stopped,   0 zombie
%Cpu(s):  1.2 us,  0.5 sy,  0.0 ni, 98.1 id,  0.0 wa,  0.0 hi,  0.2 si,  0.0 st
MiB Mem :   5921.6 total,   1425.5 free,   2038.7 used,   2457.4 buff/cache
MiB Swap:   2048.0 total,   1148.7 free,    899.3 used.   3168.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND                                    
 940326 uids0025  20   0    8340   5524   5248 S   0.0   0.1   0:00.00 test                                       

```

这样可以动态实时的看到CPU和内存的占用率，然后按q键回到命令行

### ps指令查看

- using ps cmd check memory
- changed cpu and memory occupied

```bash
ps -aux |grep test
kernoops    1005  0.0  0.0  11268  2052 ?        Ss   1月16   1:30 /usr/sbin/kerneloops --test
uids0025  941373  0.1  0.2   8340  5476 pts/1    S+   11:00   0:00 ./test
uids0025  941407  0.0  0.0  12120  2932 pts/0    S+   11:02   0:00 grep --color=auto test
```

cpu occupied 0.1
memory occupied 0.2
physical memory 5476kb

- double check process status

`VmRSS`对应的值就是物理内存占用，刚才一致

```bash
cat /proc/941373/status
Name:	test
Umask:	0022
State:	S (sleeping)
Tgid:	941373
Ngid:	0
Pid:	941373
PPid:	938795
TracerPid:	0
Uid:	10002	10002	10002	10002
Gid:	10006	10006	10006	10006
FDSize:	256
Groups:	10001 10006 10010 10011 10015 10016 10017 10019 10020 10021 10023 10043 10044 10045 10048 10049 10050 
NStgid:	941373
NSpid:	941373
NSpgid:	941373
NSsid:	938795
VmPeak:	    8372 kB
VmSize:	    8340 kB
VmLck:	       0 kB
VmPin:	       0 kB
VmHWM:	    5476 kB
VmRSS:	    5476 kB
RssAnon:	     288 kB
RssFile:	    5188 kB
RssShmem:	       0 kB
VmData:	     300 kB
VmStk:	     132 kB
VmExe:	      12 kB
VmLib:	    4072 kB
VmPTE:	      56 kB
VmSwap:	       0 kB
HugetlbPages:	       0 kB
CoreDumping:	0
THP_enabled:	1
Threads:	1
SigQ:	0/23369
SigPnd:	0000000000000000
ShdPnd:	0000000000000000
SigBlk:	0000000000000000
SigIgn:	0000000000000000
SigCgt:	0000000180000000
CapInh:	0000000000000000
CapPrm:	0000000000000000
CapEff:	0000000000000000
CapBnd:	000001ffffffffff
CapAmb:	0000000000000000
NoNewPrivs:	0
Seccomp:	0
Seccomp_filters:	0
Speculation_Store_Bypass:	thread vulnerable
SpeculationIndirectBranch:	conditional enabled
Cpus_allowed:	f
Cpus_allowed_list:	0-3
Mems_allowed:	00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000000,00000001
Mems_allowed_list:	0
voluntary_ctxt_switches:	2
nonvoluntary_ctxt_switches:	0

```

## 查看内存占用前10名的程序

```bash
ps aux | sort -k4,4nr | head -n 10
```

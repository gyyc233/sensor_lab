
# e2e_multi_view_matching

[e2e_multi_view_matching](https://github.com/barbararoessle/e2e_multi_view_matching)

- GNN-based multi-view feature matching to predict matches and confidences tailored
- Propose a graph attention network to predict image correspondences along with confidence weights. 图注意力网络
- 跨多个帧整合来自多个视图的信息，预测所有的匹配项
- 允许多视图关联来加强几何推理和置信度预测。
- 基于`SuperGlue`,使用多视图进行优化

1. end-to-end trainable pose estimation
2. multi-view graph attention network to learn feature matches simultaneously across multiple frames. 跨帧

## Related Work

1. conventional feature matching
   1. SIFT, ORB
   2. LIFT,SuperPoint(本文采用)
2. Learning feature matching
   1. CNN：缺点：匹配时缺乏全局背景，并且无法区分纹理少，重复结构少的区域
   2. SuperGlue:使用注意力GNN。所有关键点都会相互作用，因此感受野跨越两个图像，从而在宽基线设置下实现精确匹配
   3. 本文基于SuperGlue 进行改进
3. pose optimization
   1. 使用`differentiable pose optimization`为我们的特征匹配网络提供梯度，并实现显着改进的姿态估计结果

## Method

将多张图像中的关键点关联起来

### Multi-View Graph Attention Network

以SuperGlue为基础

### differentiable pose optimization

1. 初始位姿估计（8点法加权）
2. BA优化

### end-to-end training



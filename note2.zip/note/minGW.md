
cmake 生成makefile: `mkdir build && cd build` then `cmake -G "MinGW Makefiles" ..`

进入build文件夹`make`指令===`mingw32-make`


## git format-patch 生成指定commit的补丁

git format常用命令：
git format-patch -3 //从当前分支最新提交点往下共生成3个补丁
git format-patch -1 指定commit号 //生成指定commit号的补丁

## 应用补丁

git am xxxx.patch

## 查看某个patch文件统计信息

git apply --stat xxxx.patch

## 查看某个commit统计信息

git show --stat commit_id

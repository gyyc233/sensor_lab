
逗号分隔值（Comma-Separated Values，CSV，有时也称为字符分隔值，因为分隔字符也可以不是逗号），其文件以纯文本形式存储表格数据（数字和文本）

- 由记录组成（典型的是每行一条记录）
- 每条记录被分隔符分隔为字段（典型分隔符有逗号、分号或制表符；有时分隔符可以包括可选的空格）；
- individual rows are separated by a newline (‘\n’).

## read a row data

```cpp
int getCsvLineValue(const char* filename, char* buff, int row_id) {
  FILE* fp;
  int  flag = 0;
  if (NULL == (fp = fopen(filename, "r"))) {
    perror("failed to open csv file\n");
    return -1;
  }

  char row[1024];
  int index = 0;
  while (fgets(row, 1024, fp) != NULL) {
    if (index == row_id)
    {
      strcpy(buff, row);
      break;
    }
    index++;
  }

  fclose(fp);
  return 0 ;
}

int strPoints2floatPoints(const std::vector<std::string>& str_points, std::vector<float>& points_x, std::vector<float>& points_y) {
  std::vector<float> points_x_y;
  for (size_t i = 0; i < str_points.size(); i++) {
    int pre = 0;
    int cur = 0;
    for (size_t j = 0; j <= str_points[i].size(); j++) {
      if (str_points[i][j] == ',' || j == str_points[i].size()) {
        cur = j;
        std::string num_str;
        num_str = str_points[i].substr(pre, cur - pre);
        points_x_y.push_back(std::stof(num_str));
        pre = ++cur;
      }
    }
  }

  for (size_t i = 0; i < points_x_y.size(); i += 2) {
    points_x.push_back(points_x_y[i]);
    points_y.push_back(points_x_y[i + 1]);
  }

  if (points_x.size() != points_y.size()) {
    return -1;
  }
  return 0 ;
}

```

## create csv

```cpp
void create() 
{ 
  // file pointer 
  fstream fout; 

  // opens an existing csv file or creates a new file. 
  fout.open("reportcard.csv", ios::out | ios::app); 

  cout << "Enter the details of 5 students:"
  << " roll name maths phy chem bio"; 
  << endl; 

  int i, roll, phy, chem, math, bio; 
  string name; 

  // Read the input 
  for (i = 0; i < 5; i++) { 

  cin >> roll 
  	>> name 
  	>> math 
  	>> phy 
  	>> chem 
  	>> bio; 

  // Insert the data to file 
  fout << roll << ", "
  	<< name << ", "
  	<< math << ", "
  	<< phy << ", "
  	<< chem << ", "
  	<< bio 
  	<< "\n"; 
  } 
} 

```

## read a particular record

In reading a CSV file, the following approach is implemented:-

1. Using `getline()`, file pointer and ‘\n’ as the delimiter, read an entire row and store it in a string variable.
2. Using `stringstream`, separate the row into words.

- Now using getline(), the stringstream pointer and ‘, ‘ as the delimiter, read every word in the row, store it in a string variable and push that variable to a string vector.
- Retrieve a required column data through row[index](通过 row[index] 检索所需的列数据). Here, row[0] always stores the roll number of a student, so compare row[0] with the roll number input by the user, and if it matches, display the details of the student and break from the loop.

```cpp
void read_record() 
{ 

	// File pointer 
	fstream fin; 

	// Open an existing file 
	fin.open("reportcard.csv", ios::in); 

	// Get the roll number 
	// of which the data is required 
	int rollnum, roll2, count = 0; 
	cout << "Enter the roll number "
		<< "of the student to display details: "; 
	cin >> rollnum; 

	// Read the Data from the file 
	// as String Vector 
	vector<string> row; 
	string line, word, temp; 

	while (fin >> temp) { 

		row.clear(); 

		// read an entire row and 
		// store it in a string variable 'line' 
		getline(fin, line); 

		// used for breaking words 
		stringstream s(line); 

		// read every column data of a row and 
		// store it in a string variable, 'word' 
		while (getline(s, word, ', ')) { 

			// add all the column data 
			// of a row to a vector 
			row.push_back(word); 
		} 

		// convert string to integer for comparision 
		roll2 = stoi(row[0]); 

		// Compare the roll number 
		if (roll2 == rollnum) { 

			// Print the found data 
			count = 1; 
			cout << "Details of Roll " << row[0] << " : \n"; 
			cout << "Name: " << row[1] << "\n"; 
			cout << "Maths: " << row[2] << "\n"; 
			cout << "Physics: " << row[3] << "\n"; 
			cout << "Chemistry: " << row[4] << "\n"; 
			cout << "Biology: " << row[5] << "\n"; 
			break; 
		} 
	} 
	if (count == 0) 
		cout << "Record not found\n"; 
} 

```

## update a record



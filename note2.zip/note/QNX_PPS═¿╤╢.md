- [PPS](#pps)

# PPS

QNX PPS(Persistent Publish Subscribe)持久发布/订阅(PPS)服务是一个小型的、可扩展的发布和订阅服务，它提供了跨重启的持久性。它旨在为嵌入式系统中的发布/订阅和持久性提供简单易用的解决方案，满足使用异步发布和通知构建松散连接系统的需求。

PPS服务在QNX中的定位

![](QNX_PPS通讯/1.png)

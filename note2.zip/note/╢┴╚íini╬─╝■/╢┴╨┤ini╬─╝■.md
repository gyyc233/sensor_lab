
ini文件可作为于C++程序配置文件，ini的后缀名也不一定是".ini"也可以是".cfg"，".conf ”或者是".txt"。因为ini文件实质就是txt文本文件。
ini文件由section, key, value 节+键+值 组成,注释可以使用`#`或者`;`

```ini
[PARAMS]
feature_1=1
feature_2=10.0
```

获取ini key-value

```cpp
  int GetIniKeyValue(const char* title, const char* key, const char* filename, char* buff)
  {
    FILE* fp;
    int  flag = 0;
    char sTitle[64], * wTmp;
    char sLine[1024];
    sprintf(sTitle, "[%s]", title); // 发送格式化title, 输出到 sTitle 所指向的字符串，这里包含了[]中括号
    if (NULL == (fp = fopen(filename, "r"))) {
      printf("failed to open ini file\n");
      return -1;
    }

    // char *fgets(char *str, int n, FILE *stream) 从指定的流 stream 读取一行，并把它存储在 str 所指向的字符串内。
    // 当读取 (n-1) 个字符时，或者读取到换行符时，或者到达文件末尾时，它会停止，具体视情况而定
    while (NULL != fgets(sLine, 1024, fp)) {
      // int strncmp(const char *str1, const char *str2, size_t n) 把 str1 和 str2 进行比较，最多比较前 n 个字符
      if (0 == strncmp("//", sLine, 2)) continue;
      if ('#' == sLine[0])              continue;

      // char *strchr(const char *str, int c) 在参数 str 所指向的字符串中搜索第一次出现字符 c（一个无符号字符）的位置
      wTmp = strchr(sLine, '=');
      // 找到=字符，表示该行是 key=value
      if ((NULL != wTmp) && (1 == flag)) {
        // 寻找key
        if (0 == strncmp(key, sLine, strlen(key))) {
          sLine[strlen(sLine) - 1] = '\0'; // 最后一位是\0
          fclose(fp);
          while (*(wTmp + 1) == ' ') {
            wTmp++;
          }
          // 复制value到buff
          strcpy(buff, wTmp + 1);
          return 0 ;
        }
      }
      // 未找到=字符，表示该行是 section
      else {
        // 找到section
        if (0 == strncmp(sTitle, sLine, strlen(sTitle))) {
          flag = 1;
        }
      }
    }
    fclose(fp);
    return 0 ;
  }
```

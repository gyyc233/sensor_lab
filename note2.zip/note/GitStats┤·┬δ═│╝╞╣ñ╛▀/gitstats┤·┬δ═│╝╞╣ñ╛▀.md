
# gitstats代码统计工具

GitStats is a statistics generator for git (a distributed revision control system 分布式版本控制系统) repositories. It examines the repository and produces some interesting statistics from the history of it. Currently HTML is the only output format.

Features
Here is a list of some statistics generated currently:
- General statistics: total files, lines, commits, authors. 一般统计：文件总数、行数、提交数、作者数。
- Activity: commits by hour of day, day of week, hour of week, month of year, year and month, and year.
- Authors: list of authors (name, commits (%), first commit date, last commit date, age), author of month, author of year.
- Files: file count by date, extensions
- Lines: Lines of Code by date

## using

```bash
git clone git://github.com/hoxu/gitstats.git

cd gitstats

cp gitstats gitstats.py
```

## install gnuplot

`sudo apt-get install gnuplot`

## miniconda pyhton2 environment

```bash
conda activate

conda create -n py2 python=2.7

conda activate py2

python gitstats.py ../../your_project/ ../../your_project/statistic
```

first param 为工程所在目录。
second param 为结果文件目录。

## open index.html

完成后，进入目录，双击index.html文件查看统计结果。


本地检查commit包含中文的修改没有问题,push到gitlab后,中文乱码

1. 检查文件行尾设置, windows下默认是CRLF, linux下默认是LF
2. 检查文件编码, gitlab默认是UTF-8

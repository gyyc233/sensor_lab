- [vs2022 C++ 封装dll](#vs2022-c-封装dll)
  - [dll 的导入和导出关键字](#dll-的导入和导出关键字)
    - [导出一个类](#导出一个类)
    - [导出全局函数](#导出全局函数)
  - [test\_dll 实现](#test_dll-实现)
  - [配置第三方dll](#配置第三方dll)
  - [调用第三方Dll](#调用第三方dll)
- [DLL advance operator](#dll-advance-operator)

# vs2022 C++ 封装dll

选择**动态链接库(DLL)或者具有导出项的(DLL)动态链接库**，将解决方案和项目(test_dll)放到同一目录中。VS会创建对应的dll基本例子。

- 在外部依赖项里vs自动帮你链接了C++常用的库
- DllMain dll的进入点函数
- DLL的入口点函数调用堆栈顺序
  - _DllMainCRTStartup ==>> dllmain_dispatch ==>> DllMain
- 假定该vs dll 项目名字 **test_dll** 则vs会自动生成 `test_dll.h` `test_dll.cpp`

## dll 的导入和导出关键字

_declspec(dllimport) 和 __declspec(dllexport)

- __declspec是Microsoft VC中专用的关键字，它配合着一些属性可以对标准C/C++进行扩充。__declspec关键字应该出现在声明的前面
- __declspec(dllexport)用于Windows中的动态库中，声明导出函数、类、对象等供外面调用，省略给出.def文件。即将函数、类等声明为导出函数，供其它程序调用，作为动态库的对外接口函数、类等
- __declspec(dllimport)用于Windows中，从别的动态库中声明导入函数、类、对象等供本动态库或exe文件使用。
- 当你需要使用DLL中的函数时，往往不需要显示地导入函数，编译器可自动完成。
- 不使用__declspec(dllimport)也能正确编译代码，但使用__declspec(dllimport)使编译器可以生成更好的代码。编译器之所以能够生成更好的代码，是因为它可以确定函数是否存在于DLL中，这使得编译器可以生成跳过间接寻址级别的代码，而这些代码通常会出现在跨DLL边界的函数调用中。声明一个导入函数，是说这个函数是从别的DLL导入。一般用于使用某个DLL的exe中

### 导出一个类

```cpp
#ifdef DLLEXPORT
#define _DLL_DECLARE_ declspec(dllexport)
#else
#define _DLL_DECLARE_ declspec(dllimport)

class _DLL_DECLARE_ Math
{
public:
      double Add(double a, double b);
      double Sub(double a, double b);
};
```

### 导出全局函数

```cpp
__declspec(dllexport) double myFunc(double a, double b);
```

在对应的使用该方法的地方需要显示的导入该方法才可以使用

```cpp
__declspec(dllimport) double myFunc(double a, double b);使用.def文件
```

".def"文件是类似于ld连接器的连接脚本文件，可以被当作link连接器的输入文件，用域控制链接过程。“.def”文件中的IMPORT或者EXPORTS段可以用来声明导入导出符号。

## test_dll 实现

添加了一个成员函数

test_dll.h

```cpp
#ifdef TESTDLL_EXPORTS
#define TESTDLL_API __declspec(dllexport)
#else
#define TESTDLL_API __declspec(dllimport)
#endif

// 此类是从 dll 导出的
class TESTDLL_API Ctestdll {
public:
	Ctestdll(void);
	// TODO: 在此处添加方法。
	void setFeature();
};

extern TESTDLL_API int ntestdll;

TESTDLL_API int fntestdll(void);
```

test_dll.cpp

```cpp
#include "pch.h"
#include "framework.h"
#include "test_dll.h"
#include "iostream"


// 这是导出变量的一个示例
TESTDLL_API int ntestdll=0;

// 这是导出函数的一个示例。
TESTDLL_API int fntestdll(void)
{
    return 0;
}

// 这是已导出类的构造函数。
Ctestdll::Ctestdll()
{
    return;
}

void Ctestdll::setFeature() {
  std::cout << "test dll" << std::endl;
}
```

built 生成-》生成test_dll.dll

```
1>------ 已启动全部重新生成: 项目: test_dll, 配置: Release x64 ------
1>pch.cpp
1>dllmain.cpp
1>test_dll.cpp
1>  正在创建库 D:\yongchao_gan\work_space\code\test_dll\x64\Release\testdll.lib 和对象 D:\yongchao_gan\work_space\code\test_dll\x64\Release\testdll.exp
1>正在生成代码
1>Previous IPDB not found, fall back to full compilation.
1>All 16 functions were compiled because no usable IPDB/IOBJ from previous compilation was found.
1>已完成代码的生成
1>test_dll.vcxproj -> D:\yongchao_gan\work_space\code\test_dll\x64\Release\testdll.dll
```

可以在./test_dll/x64/Release and ./test_dll下找到 testdll.dll testdll.lib test_dll.h

## 配置第三方dll

创建空项目 Project1,在目录下新建 include/ lib/ 分别保存test_dll.h testdll.lib,testdll.lib

- 导入头文件，添加包含目录

![alt text](image.png)

- 导入lib库，附加库目录

![alt text](image-1.png)

- 添加生成后事件 将 .dll 在项目生成后拷贝到对应文件夹

![alt text](image-2.png)

## 调用第三方Dll

在Project1空项目的源文件新建 main.cpp

```cpp
#include "iostream"
#include "test_dll.h"

int main() {
  Ctestdll* dll_test = new Ctestdll();
  dll_test->setFeature();
  delete dll_test;

  fntestdll();

  std::cout << ntestdll << std::endl;
  return 0;
}
```

生成并输出结果

# DLL advance operator

-[ref](https://zhuanlan.zhihu.com/p/363408701)

- 隐式链接dll

```cpp
// 1. 包含 dll文件的.h头文件，.lib导入库文件
#include "pch.h"
#pragma comment(lib, "Dll1.lib")
// 这样，在dll中的导出函数就可以直接在exe的源代码中使用了
// 2. 将dll文件与.exe文件一起发布
```

- 显示链接和卸载DLL
  - 显示链接DLL：LoadLibraryA

  ```cpp
    // 利用 LoadLibraryA函数，加载指定的DLL
    // 参数：dll模块的路径
    HMODULE hdd = LoadLibraryA("Dll1.dll");

    // GetProcAddress：获取指定模块中的函数地址
    // 参数1：模块句柄
    // 参数2：函数名称
    DWORD dwFunc = (DWORD)GetProcAddress(hdd, "add");
    __asm
    {
    push eax
    mov eax, dwFunc
    call eax
    pop eax
    }
  ```
  - 卸载DLL
  ```cpp
	// FreeLibrary：卸载指定的模块
	// 参数：模块句柄
	FreeLibrary(hdd);
	
	// FreeLibraryAndExitThread：卸载指定模块，并退出当前线程
	// 参数1：模块句柄
	// 参数2：线程退出代码
	FreeLibraryAndExitThread(hdd, 0);
  ```



# Apply matplotlib_cpp

- install python3 and matplotlib

```bash
sudo apt-get install python3-matplotlib python3-dev
```

- check matplotlib and numpy

```bash
pip show matplotlib
pip show numpy
```

- clone matplotlib-cpp

```bash
git clone https://github.com/lava/matplotlib-cpp
```

- copy `matplotlibcpp.h` to your CMake project path `./include/common`

- edited CMakeLists.txt

```
# ================================================================
# add matplotlib-cpp

option(MATPLOTLIB_CPP "Build with matplotlib-cpp, defualt OFF" OFF)

if(MATPLOTLIB_CPP)
  add_definitions(-DMATPLOTLIB_CPP)

  add_library(matplotlib_cpp INTERFACE)
  # check the path
  target_include_directories(matplotlib_cpp INTERFACE include/common)
  target_compile_features(matplotlib_cpp INTERFACE
    cxx_std_11
  )
  # TODO: Use `Development.Embed` component when requiring cmake >= 3.18
  find_package(Python3 COMPONENTS Interpreter Development REQUIRED)
  target_link_libraries(matplotlib_cpp INTERFACE
    Python3::Python
    Python3::Module
  )
  find_package(Python3 COMPONENTS NumPy)
  if(Python3_NumPy_FOUND)
    target_link_libraries(matplotlib_cpp INTERFACE
      Python3::NumPy
    )
  else()
    target_compile_definitions(matplotlib_cpp INTERFACE WITHOUT_NUMPY)
  endif()
  install(
    TARGETS matplotlib_cpp
    EXPORT install_targets
  )
endif()
# ================================================================

# ...
if(MATPLOTLIB_CPP)
  target_link_libraries(your_project matplotlib_cpp)
else()
  target_link_libraries(your_project)
endif()

```

## using

```cpp
// ...
#ifdef MATPLOTLIB_CPP
#include "matplotlibcpp.h"
#endif

//...
#ifdef MATPLOTLIB_CPP
namespace plt = matplotlibcpp;
#endif

#ifdef MATPLOTLIB_CPP
  std::vector<double> test_x;
  std::vector<double> test_y;

  for (auto i = 0; i <= 10; i ++) {
    test_x.push_back(i);
    test_y.push_back(i*i);
  }

  plt::plot(test_x, test_y);
  plt::show();
#endif
```

![alt text](image.png)
